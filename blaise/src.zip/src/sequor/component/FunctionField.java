/*
 * FunctionField.java
 * Created on Oct 24, 2007, 9:04:33 PM
 */

package sequor.component;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.EventListenerList;
import scio.function.Function;
import scribo.parser.Parser;
import scribo.tree.FunctionTreeNode;
import scribo.tree.FunctionTreeRoot;

/**
 *
 * @author ae3263
 */
public class FunctionField extends JTextField {
    FunctionTreeRoot compiled;
    
    public FunctionField(){
        super();
        setText("0");
        initEventListening();
        textUpdated();
    }

    public FunctionField(String initial){
        this();
        setText(initial);
    }
    

    public void initEventListening(){
        getDocument().addDocumentListener(new DocumentListener(){
            public void insertUpdate(DocumentEvent e) {textUpdated();}
            public void removeUpdate(DocumentEvent e) {textUpdated();}
            public void changedUpdate(DocumentEvent e) {textUpdated();}
        });
    }
    
    /** Returns underlying function. */
    public Function getFunction(){return compiled;}
    
    /** Changes underlying function and generates change events if necessary. */
    public void textUpdated(){
        FunctionTreeNode attempt=Parser.parseExpression(getText());
        if(attempt!=null){
            compiled=new FunctionTreeRoot(attempt);
            fireStateChanged();
            setForeground(Color.BLACK);
        }else{
            setForeground(Color.RED);
        }
    }
    
    
    // EVENT HANDLING
    
    /** Event handling code copied from DefaultBoundedRangeModel. */      
    protected ChangeEvent changeEvent=new ChangeEvent("FunctionField");
    protected EventListenerList listenerList=new EventListenerList();    
    public void addChangeListener(ChangeListener l){listenerList.add(ChangeListener.class,l);}
    public void removeChangeListener(ChangeListener l){listenerList.remove(ChangeListener.class,l);}
    protected void fireStateChanged(){
        Object[] listeners=listenerList.getListenerList();
        for(int i=listeners.length-2; i>=0; i-=2){
            if(listeners[i]==ChangeListener.class){
                if(changeEvent==null){return;}
                ((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
            }
        }
    }    
}
