/*
 * FunctionTreeRoot.java
 * Created on Sep 21, 2007, 2:58:57 PM
 */

// TODO Add equality root node.
// TODO Add list of variables at FunctionRoot/setting variable values at the top

package scribo.tree;

import java.util.HashMap;
import scio.function.Function;

/**
 * Represents the root of a function tree. Should not be addable to any other tree node,
 * and simply returns the argument's value. Implemented like an identity function.<br><br>
 * Part of the reason for this is to maintain a list of variables used in the underlying tree,
 * so that it may properly implement the Function command.<br><br>
 * This is essentially just a wrapper class.
 * 
 * @author Elisha
 */
public class FunctionTreeRoot extends FunctionTreeFunctionNode implements Function<Double,Double>{
    public FunctionTreeRoot(FunctionTreeNode c) {addSubNode(c);}
    public Double getValue(HashMap<Variable,Double> table){return numSubNodes()==1?argumentValue(table):null;}
    @Override
    public String toString(){return numSubNodes()==1?argumentString():null;}
    @Override
    public FunctionTreeNode derivativeTree(Variable v){return numSubNodes()==1?argumentDerivative(v):null;}
    @Override
    public boolean isValidSubNode(){return false;}
    @Override
    public FunctionTreeNode simplified(){return isNumber()?new Constant(getValue()).simplified():new FunctionTreeRoot(argumentSimplified());}
    public Class inverseFunctionClass(){return null;}
    public void initFunctionType(){}

    // Function methods
    public Double getValue(Double x){
        return getValue("x",x);
    }
    public Double minValue(){return 0.0;}
    public Double maxValue(){return 0.0;}    
}
