/*
 * Series.java
 * Created on Oct 8, 2007, 3:34:28 PM
 */

package scribo.tree;

import java.util.HashMap;

/**
 * Implements an indexed series of nodes, which are either summed or multiplied.<br><br>
 * 
 * @author Elisha
 */
public abstract class Series extends FunctionTreeFunctionNode{
    double min;
    double max;
    double step;
    Variable index;
    
    public Series(FunctionTreeNode ftn,Variable index,double min,double max,double step){
        super(ftn);
        this.index=index;
        this.min=min;
        this.max=max;
        this.step=step;
    }
    @Override
    public String toString(){return getFunctionName()+"("+argumentString()+","+min+","+max+","+step+")";}
        
    public static class Add extends Series {
        public Add(FunctionTreeNode ftn,Variable index,double min,double max,double step){super(ftn,index,min,max,step);}
        public void initFunctionType(){setFunctionNames("Sum",null,null,null);}
        public Double getValue(HashMap<Variable, Double> table){
            double result=0;
            table.put(index,min);
            for(double i=min;i<=max;i+=step){table.put(index,i);result+=argumentNode().getValue(table);}
            return result;
        }
    }
    
    public static class Multiply extends Series {
        public Multiply(FunctionTreeNode ftn,Variable index,double min,double max,double step){super(ftn,index,min,max,step);}
        public void initFunctionType(){setFunctionNames("Prod",null,null,null);}
        public Double getValue(HashMap<Variable, Double> table){
            double result=1;
            table.put(index,min);
            for(double i=min;i<=max;i+=step){table.put(index,i);result*=argumentNode().getValue(table);}
            return result;
        }
    }
}
